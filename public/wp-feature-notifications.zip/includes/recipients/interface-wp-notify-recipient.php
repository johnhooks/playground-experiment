<?php

interface WP_Notify_Recipient {

}
