<?php

namespace WP\Notifications\Exceptions;

class Runtime_Exception
	extends \RuntimeException
	implements Exception {

}
