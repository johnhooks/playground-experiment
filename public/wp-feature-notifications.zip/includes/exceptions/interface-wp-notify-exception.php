<?php

interface WP_Notify_Exception {

}
