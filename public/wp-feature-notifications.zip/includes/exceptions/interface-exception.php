<?php

namespace WP\Notifications\Exceptions;

interface Exception {

}
