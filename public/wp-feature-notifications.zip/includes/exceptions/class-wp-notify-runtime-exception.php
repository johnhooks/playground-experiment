<?php

class WP_Notify_Runtime_Exception
	extends RuntimeException
	implements WP_Notify_Exception {

}
