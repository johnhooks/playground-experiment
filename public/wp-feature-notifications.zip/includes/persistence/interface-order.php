<?php

namespace WP\Notifications\Persistence;

interface Order {

	const ASCENDING  = 'asc';
	const DESCENDING = 'desc';
}
