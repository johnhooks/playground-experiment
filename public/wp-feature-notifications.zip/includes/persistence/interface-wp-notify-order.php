<?php

interface WP_Notify_Order {

	const ASCENDING  = 'asc';
	const DESCENDING = 'desc';
}
