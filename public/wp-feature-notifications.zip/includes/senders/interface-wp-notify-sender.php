<?php

interface WP_Notify_Sender extends JsonSerializable {

}
