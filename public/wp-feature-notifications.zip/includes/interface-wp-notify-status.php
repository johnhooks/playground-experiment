<?php

interface WP_Notify_Status {

	const UNREAD = 'unread';
	const READ   = 'read';
}
