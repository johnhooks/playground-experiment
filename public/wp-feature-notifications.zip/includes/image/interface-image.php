<?php

namespace WP\Notifications\Image;

use JsonSerializable;

use WP\Notifications;

interface Image extends JsonSerializable {

}
