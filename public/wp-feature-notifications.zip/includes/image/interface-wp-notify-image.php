<?php

interface WP_Notify_Image extends JsonSerializable, WP_Notify_Json_Unserializable {

}
